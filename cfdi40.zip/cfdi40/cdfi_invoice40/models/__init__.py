# -*- coding: utf-8 -*-

from . import catalogos
from . import res_company
from . import res_partner
from . import product
from . import account_tax
from . import account_invoice
from . import account_payment
from . import account_journal
from . import sale
from . import amount_to_text_es_MX
from . import purchase
from . import res_currency
